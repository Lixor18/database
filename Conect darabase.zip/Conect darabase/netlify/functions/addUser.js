// functions/addUser.js
exports.handler = async function(event, context) {
    // Додаємо CORS заголовки для дозволу запитів з https://conectm.netlify.app
    const headers = {
      'Access-Control-Allow-Origin': 'https://conectm.netlify.app',  // Дозволяємо запити з першого сайту
      'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',  // Дозволяємо методи POST, GET, OPTIONS
      'Access-Control-Allow-Headers': 'Content-Type',  // Дозволяємо Content-Type заголовок
    };
  
    // Логіка додавання користувача
    if (event.httpMethod === 'POST') {
      try {
        const { username, email } = JSON.parse(event.body);
        // Ваш код для збереження користувача
        return {
          statusCode: 200,
          body: JSON.stringify({ message: 'User added successfully' }),
          headers,
        };
      } catch (error) {
        return {
          statusCode: 500,
          body: JSON.stringify({ message: 'Error adding user' }),
          headers,
        };
      }
    }
  
    // Якщо запит не POST
    return {
      statusCode: 405,  // Method Not Allowed
      body: JSON.stringify({ message: 'Method not allowed' }),
      headers,
    };
  };
  